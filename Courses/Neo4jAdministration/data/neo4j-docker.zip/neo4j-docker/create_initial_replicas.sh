
# create the container instances

docker run --name=replica1 \
        --volume=`pwd`/replica1/conf:/conf --volume=`pwd`/replica1/data:/data --volume=`pwd`/replica1/logs:/logs  \
        --publish=21474:7474 --publish=21687:7687 \
	--env=NEO4J_dbms_connector_bolt_advertised__address=localhost:21687 \
        --network=training-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000,core4:5000,core5:5000 \
        --env=NEO4J_dbms_mode=READ_REPLICA \
        --detach \
        $1

docker run --name=replica2 \
        --volume=`pwd`/replica2/conf:/conf --volume=`pwd`/replica2/data:/data --volume=`pwd`/replica2/logs:/logs  \
        --publish=22474:7474 --publish=22687:7687 \
	--env=NEO4J_dbms_connector_bolt_advertised__address=localhost:22687 \
        --network=training-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000,core4:5000,core5:5000 \
        --env=NEO4J_dbms_mode=READ_REPLICA \
       	--detach \
        $1

# stop the containers

docker stop replica1 replica2

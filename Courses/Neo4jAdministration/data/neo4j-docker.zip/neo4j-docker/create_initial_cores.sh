# create the cluster network that will enable containers to communicate with each other

docker network create training-cluster

# create the container instances

docker run --name=core1 \
        --volume=`pwd`/core1/conf:/conf --volume=`pwd`/core1/data:/data --volume=`pwd`/core1/logs:/logs  \
        --publish=11474:7474 --publish=11687:7687 \
        --env=NEO4J_dbms_connector_bolt_advertised__address=localhost:11687 \
	--network=training-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000,core4:5000,core5:5000 \
        --env=NEO4J_dbms_mode=CORE \
        --detach \
        $1

docker run --name=core2 \
        --volume=`pwd`/core2/conf:/conf --volume=`pwd`/core2/data:/data --volume=`pwd`/core2/logs:/logs  \
        --publish=12474:7474 --publish=12687:7687 \
	--env=NEO4J_dbms_connector_bolt_advertised__address=localhost:12687 \
        --network=training-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000,core4:5000,core5:5000 \
        --env=NEO4J_dbms_mode=CORE \
        --detach \
        $1

docker run --name=core3 \
        --volume=`pwd`/core3/conf:/conf --volume=`pwd`/core3/data:/data --volume=`pwd`/core3/logs:/logs  \
        --publish=13474:7474 --publish=13687:7687 \
	--env=NEO4J_dbms_connector_bolt_advertised__address=localhost:13687 \
        --network=training-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
	--env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000,core4:5000,core5:5000 \
        --env=NEO4J_dbms_mode=CORE \
	--detach \
        $1

# stop the containers

docker stop core1 core2 core3

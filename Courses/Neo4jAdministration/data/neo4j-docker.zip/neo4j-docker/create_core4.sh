
# create the container instances

docker run --name=core4 \
        --volume=`pwd`/core4/conf:/conf --volume=`pwd`/core4/data:/data --volume=`pwd`/core4/logs:/logs  \
        --publish=14474:7474 --publish=14687:7687 \
        --env=NEO4J_dbms_connector_bolt_advertised__address=localhost:14687 \
	--network=training-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000,core4:5000,core5:5000 \
        --env=NEO4J_dbms_mode=CORE \
        --detach \
        $1

# stop the container

docker stop core4

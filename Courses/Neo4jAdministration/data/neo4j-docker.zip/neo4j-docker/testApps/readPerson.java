import org.neo4j.driver.v1.*;

public class readPerson
{
	public static void main (String[] args)
   { 	   
      String driverString = args[0] + "://localhost:" + args[1];
      System.out.println ("driverString is " + driverString);   
      Driver driver = GraphDatabase.driver( driverString , AuthTokens.basic( "neo4j", "training-helps" ) );
      Session session = driver.session();
      
     try
     {  
      String matchStatement = "MATCH (a:Person) WHERE a.name = '" + args[2] + "' RETURN a.name AS name, a.title AS title";
      StatementResult result = session.run( matchStatement );
      while ( result.hasNext() )
      {    
        Record record = result.next();
        System.out.println( "***************** Record found: " + record.get( "title" ).asString() + " " + record.get("name").asString() );
      }

      session.close();
     driver.close();
     }
      catch (Exception e)
      {
              System.out.println("Cannot read from this server!");
              System.exit(0);
      }
   } 
}

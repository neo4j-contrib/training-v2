#!/bin/bash

case $1 in
 -[h?] | --help)
    cat <<-____HALP
        Usage: ${0##*/} bolt-protocol port
____HALP
        exit 0;;
esac

javac -cp ./neo4j-java-driver-1.7.2.jar testRead.java
java -cp .:./neo4j-java-driver-1.7.2.jar testRead $1  $2

import org.neo4j.driver.v1.*;

public class testRead
{
	public static void main (String[] args)
   { 	   
      String driverString = args[0] + "://localhost:" + args[1];
      System.out.println ("driverString is " + driverString);   
      Driver driver = GraphDatabase.driver( driverString , AuthTokens.basic( "neo4j", "training-helps" ) );
      Session session = driver.session();
      
      try {
      
      StatementResult result = session.run( "MATCH (a:Person) WHERE a.name = 'Tom Hanks' RETURN a.name AS name" );
      while ( result.hasNext() )
      {    
              Record record = result.next();
	      System.out.println( "******************** " + record.get( "name" ).asString() + " found in Movie database.");
      }

      session.close();
     driver.close();
     }
      catch (Exception e)
      {
              System.out.println("Cannot read from  this server!");
              System.exit(0);
      }
   } 
}

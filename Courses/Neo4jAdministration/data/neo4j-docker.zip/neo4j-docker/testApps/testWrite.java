import org.neo4j.driver.v1.*;

public class testWrite
{
	public static void main (String[] args)
   { 	   
      String driverString = args[0] + "://localhost:" + args[1];
      System.out.println ("driverString is " + driverString);   
      Driver driver = GraphDatabase.driver( driverString , AuthTokens.basic( "neo4j", "training-helps" ) );
      Session session = driver.session();
      
      try {
      session.run( "CREATE (a:Person {name:'Arthur', title:'King'})" );
      
      StatementResult result = session.run( "MATCH (a:Person) WHERE a.name = 'Arthur' RETURN a.name AS name, a.title AS title" );
      while ( result.hasNext() )
      {    
        Record record = result.next();
        System.out.println( "***************** Record created: " + record.get( "title" ).asString() + " " + record.get("name").asString() );
      }

      session.run( "MATCH (a:Person {name:'Arthur', title:'King'})  DELETE a" );

      session.close();
     driver.close();
     }
      catch (Exception e)
      {
              System.out.println("Cannot write to this server!");
              System.exit(0);
      }
   } 
}

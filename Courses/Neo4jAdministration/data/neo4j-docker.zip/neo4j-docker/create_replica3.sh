
# create the container instances

docker run --name=replica3 \
        --volume=`pwd`/replica3/conf:/conf --volume=`pwd`/replica3/data:/data --volume=`pwd`/replica3/logs:/logs  \
        --publish=23474:7474 --publish=23687:7687 \
	--env=NEO4J_dbms_connector_bolt_advertised__address=localhost:21687 \
        --network=training-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000,core4:5000,core5:5000 \
        --env=NEO4J_dbms_mode=READ_REPLICA \
        --detach \
        $1


# stop the container

docker stop replica3

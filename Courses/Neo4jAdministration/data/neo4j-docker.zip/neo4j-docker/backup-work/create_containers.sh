# create the cluster network that will enable containers to communicate with each other
  
docker network create test-backup-cluster

# create the container instances

docker run --name=bcore1 \
        --volume=`pwd`/bcore1/conf:/conf --volume=`pwd`/bcore1/data:/data --volume=`pwd`/bcore1/logs:/logs  \
        --publish=17474:7474 --publish=17687:7687 \
        --env=NEO4J_dbms_connector_bolt_advertised__address=localhost:17687 \
        --network=test-backup-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
        --env=NEO4J_causal__clustering_initial__discovery__members=bcore1:5000,bcore2:5000,bcore3:5000 \
        --env=NEO4J_dbms_mode=CORE \
	--detach \
        $1

docker run --name=bcore2 \
        --volume=`pwd`/bcore2/conf:/conf --volume=`pwd`/bcore2/data:/data --volume=`pwd`/bcore2/logs:/logs  \
        --publish=18474:7474 --publish=18687:7687 \
        --env=NEO4J_dbms_connector_bolt_advertised__address=localhost:18687 \
        --network=test-backup-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
        --env=NEO4J_causal__clustering_initial__discovery__members=bcore1:5000,bcore2:5000,bcore3:5000 \
        --env=NEO4J_dbms_mode=CORE \
	--detach \
        $1

docker run --name=bcore3 \
        --volume=`pwd`/bcore3/conf:/conf --volume=`pwd`/bcore3/data:/data --volume=`pwd`/bcore3/logs:/logs  \
        --publish=19474:7474 --publish=19687:7687 \
        --env=NEO4J_dbms_connector_bolt_advertised__address=localhost:19687 \
        --network=test-backup-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
        --env=NEO4J_causal__clustering_initial__discovery__members=bcore1:5000,bcore2:5000,bcore3:5000 \
        --env=NEO4J_dbms_mode=CORE \
        --detach \
        $1

docker run --name=breplica1 \
        --volume=`pwd`/breplica1/conf:/conf --volume=`pwd`/breplica1/data:/data --volume=`pwd`/breplica1/logs:/logs  \
        --publish=24474:7474 --publish=24687:7687 \
        --env=NEO4J_dbms_connector_bolt_advertised__address=localhost:24687 \
        --network=test-backup-cluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_initial__discovery__members=bcore1:5000,bcore2:5000,bcore3:5000 \
        --env=NEO4J_dbms_mode=READ_REPLICA \
        --detach \
        $1

# stop the containers

docker stop bcore1 bcore2 bcore3 breplica1

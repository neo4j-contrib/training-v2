# create the cluster network that will enable containers to communicate with each other

# set up the logs folders for each container

mkdir `pwd`/core1/logs
mkdir `pwd`/core2/logs
mkdir `pwd`/core3/logs
mkdir `pwd`/replica1/logs
mkdir `pwd`/replica2/logs

chmod 777 `pwd`/core1/logs
chmod 777 `pwd`/core2/logs
chmod 777 `pwd`/core3/logs
chmod 777 `pwd`/replica1/logs
chmod 777 `pwd`/replica2/logs

# create the network that the cluster will use
docker network create testcluster

# create the container instances
# you must substitute XXImage ID hereXX with the CONTAINER ID of the Neo4j Enterprise 3.5.0 image
# the volume requires the absolute path

docker run --name=core1 \
        --volume=`pwd`/core1/conf:/conf --volume=`pwd`/core1/data:/data --volume=`pwd`/core1/logs:/logs  \
        --publish=17474:7474 --publish=17687:7687 \
        --env=NEO4J_dbms_connector_bolt_advertised__address=localhost:17687 \
	--network=testcluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000 \
        --env=NEO4J_dbms_mode=CORE \
        --detach \
        XXImage ID hereXX

docker run --name=core2 \
        --volume=`pwd`/core2/conf:/conf --volume=`pwd`/core2/data:/data --volume=`pwd`/core2/logs:/logs  \
        --publish=18474:7474 --publish=18687:7687 \
	--env=NEO4J_dbms_connector_bolt_advertised__address=localhost:18687 \
        --network=testcluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
    	--env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000 \
        --env=NEO4J_dbms_mode=CORE \
        --detach \
        XXImage ID hereXX

docker run --name=core3 \
        --volume=`pwd`/core3/conf:/conf --volume=`pwd`/core3/data:/data --volume=`pwd`/core3/logs:/logs  \
        --publish=19474:7474 --publish=19687:7687 \
	--env=NEO4J_dbms_connector_bolt_advertised__address=localhost:19687 \
        --network=testcluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
	--env=NEO4J_causal__clustering_minimum__core__cluster__size__at__formation=3 \
        --env=NEO4J_causal__clustering_minimum__core__cluster__size__at__runtime=3 \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000 \
        --env=NEO4J_dbms_mode=CORE \
	--detach \
        XXImage ID hereXX

docker run --name=replica1 \
        --volume=`pwd`/replica1/conf:/conf --volume=`pwd`/replica1/data:/data --volume=`pwd`/replica1/logs:/logs  \
        --publish=20474:7474 --publish=20687:7687 \
	--env=NEO4J_dbms_connector_bolt_advertised__address=localhost:20687 \
        --network=testcluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000 \
        --env=NEO4J_dbms_mode=READ_REPLICA \
        --detach \
       XXImage ID hereXX

docker run --name=replica2 \
        --volume=`pwd`/replica2/conf:/conf --volume=`pwd`/replica2/data:/data --volume=`pwd`/replica2/logs:/logs  \
        --publish=21474:7474 --publish=21687:7687 \
	--env=NEO4J_dbms_connector_bolt_advertised__address=localhost:20687 \
        --network=testcluster \
        --env=NEO4J_ACCEPT_LICENSE_AGREEMENT=yes  \
        --env=NEO4J_causal__clustering_initial__discovery__members=core1:5000,core2:5000,core3:5000 \
        --env=NEO4J_dbms_mode=READ_REPLICA \
       	--detach \
        XXImage ID hereXX

# stop the containers

docker stop core1 core2 core3 replica1 replica2
